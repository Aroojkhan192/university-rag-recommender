"""
app.py
----------------
Simple Streamlit UI for the RAG-based University Recommendation System.

Run:
    streamlit run app.py
"""

import streamlit as st
from src.recommend import recommend

st.set_page_config(page_title="University Recommender (RAG)", page_icon="🎓")

st.title("🎓 RAG-Based University Recommendation System")
st.write(
    "Describe what you're looking for (field of study, city, budget) and "
    "get grounded, retrieval-augmented recommendations."
)

query = st.text_area(
    "Tell us about your goals:",
    placeholder="e.g. I want to study Artificial Intelligence in Islamabad with a budget under 400,000 PKR per year",
)

if st.button("Get Recommendations") and query.strip():
    with st.spinner("Retrieving relevant universities and generating recommendation..."):
        result = recommend(query)
    st.subheader("Recommendation")
    st.write(result)
