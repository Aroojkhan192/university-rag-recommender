"""
build_index.py
----------------
Loads the university dataset, converts each university into a LangChain
Document, embeds it using a local HuggingFace sentence-transformer model,
and builds a FAISS vector store for fast semantic retrieval.

Run this once before using the recommender:
    python src/build_index.py
"""

import json
import os

from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.docstore.document import Document

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "universities.json")
INDEX_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "faiss_index")

EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def load_universities(path: str) -> list[dict]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def university_to_document(uni: dict) -> Document:
    """Turn a university record into a single searchable text chunk."""
    content = (
        f"University: {uni['name']}\n"
        f"Location: {uni['location']}\n"
        f"Programs offered: {', '.join(uni['programs'])}\n"
        f"Approximate tuition per year (PKR): {uni['tuition_per_year_pkr']}\n"
        f"National ranking: {uni['ranking_national']}\n"
        f"About: {uni['description']}"
    )
    return Document(page_content=content, metadata={"name": uni["name"]})


def build_and_save_index() -> None:
    universities = load_universities(DATA_PATH)
    documents = [university_to_document(u) for u in universities]

    print(f"Loaded {len(documents)} university records.")
    print(f"Loading embedding model: {EMBEDDING_MODEL} ...")
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

    print("Building FAISS vector store ...")
    vectorstore = FAISS.from_documents(documents, embeddings)

    vectorstore.save_local(INDEX_PATH)
    print(f"Vector store saved to: {INDEX_PATH}")


if __name__ == "__main__":
    build_and_save_index()
