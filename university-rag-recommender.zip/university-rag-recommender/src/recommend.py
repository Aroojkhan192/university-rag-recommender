"""
recommend.py
----------------
Core RAG pipeline: given a free-text student profile (interests, budget,
preferred city, field of study), retrieve the most relevant universities
from the FAISS vector store, then use a local HuggingFace text-generation
model to write a short, grounded recommendation based ONLY on the
retrieved context (retrieval-augmented generation).

Run:
    python src/recommend.py "I want to study AI in Islamabad, budget under 400000 PKR"
"""

import os
import sys

from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from transformers import pipeline

INDEX_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "faiss_index")
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
GENERATION_MODEL = "google/flan-t5-base"

TOP_K = 3


def load_vectorstore() -> FAISS:
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
    return FAISS.load_local(
        INDEX_PATH, embeddings, allow_dangerous_deserialization=True
    )


def retrieve_context(vectorstore: FAISS, query: str, k: int = TOP_K):
    results = vectorstore.similarity_search(query, k=k)
    return results


def build_prompt(query: str, context_docs) -> str:
    context_text = "\n\n".join(doc.page_content for doc in context_docs)
    prompt = (
        "You are a helpful university admissions advisor. "
        "Using ONLY the university information provided below, "
        "recommend the best matching universities for the student and "
        "briefly explain why each one fits their profile.\n\n"
        f"University information:\n{context_text}\n\n"
        f"Student profile / request: {query}\n\n"
        "Recommendation:"
    )
    return prompt


def generate_recommendation(prompt: str) -> str:
    generator = pipeline("text2text-generation", model=GENERATION_MODEL, max_length=256)
    output = generator(prompt)[0]["generated_text"]
    return output


def recommend(query: str) -> str:
    vectorstore = load_vectorstore()
    context_docs = retrieve_context(vectorstore, query)

    print("\n--- Retrieved universities (top matches) ---")
    for doc in context_docs:
        print(f"- {doc.metadata['name']}")

    prompt = build_prompt(query, context_docs)
    recommendation = generate_recommendation(prompt)
    return recommendation


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python src/recommend.py "your student profile / query here"')
        sys.exit(1)

    user_query = " ".join(sys.argv[1:])
    print(f"\nQuery: {user_query}")

    result = recommend(user_query)
    print("\n--- Recommendation ---")
    print(result)
